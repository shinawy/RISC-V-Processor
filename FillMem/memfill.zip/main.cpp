/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{   // this is to parse the hexadecimal instruction into four parts 
    //NOTE: Please refer to the output file output.txt and delete the last line before copying as it will be duplicated with red marker, don't know why?
    //NOTE: if you have a binary file you have to change the code a little bit to support the binary parsing
    //THE NAME of the cpp file  is misleading, ignore it XD
    
    ifstream infile;
    infile.open("input.txt");
    
    ofstream outfile;
    outfile.open("output.txt");
    char ch;
    string line;
    int count=4;
    outfile<<"{mem[3],mem[2],mem[1],mem[0]}=32'h00000033;"<<endl;
    while(!infile.eof()){
       
        getline(infile,line);
        // outfile<<line<<endl;
        
        outfile<<"{mem["<<count+3 <<"],mem["<< count+2<<"],mem["<< count+1<<"],mem["<<count <<"]}=32'h"<<line<<";"<<endl;
       
        count+=4; 
        
        
    }
    

    return 0;
}
